#!/usr/bin/env python3
"""Offline aperture-aware QS/HF analysis. See METHOD.md for input schemas."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
K=['run','direction','step']
Q=K+['v_before_V','v_after_V','a_s','b_s','i_A','u_i_A','leak_A','u_leak_ind_A','u_dt_s','pre_settled']
H=K+['start_s','end_s','plateau_start_s','plateau_end_s','frequency_Hz','g_S','b_S','vac_rms_V','vdc_V']

def read(path,cols):
    d=pd.read_csv(path)
    if not set(cols)<=set(d): raise ValueError('Missing columns: '+str(set(cols)-set(d)))
    return d

def avg(a,b,t):
    return t*np.exp(-a/t)*(-np.expm1(-(b-a)/t))/(b-a)

def model(p,a,b,n):
    return p[0]+sum(p[1+2*j]*avg(a,b,np.exp(p[2+2*j])) for j in range(n))

def area(p,l,r,n):
    return p[0]*(r-l)+sum(p[1+2*j]*np.exp(p[2+2*j])*(np.exp(-l/np.exp(p[2+2*j]))-np.exp(-r/np.exp(p[2+2*j]))) for j in range(n))

def fit(a,b,y,u,n):
    scale=max(np.max(np.abs(y)),np.max(u),1e-30)
    tmin=max(np.min(b-a)/100,1e-10); tmax=max(b[-1]*100,tmin*1000)
    taus=np.geomspace(max(tmin*2,b[-1]/100),max(tmin*4,b[-1]/3),n)
    initial=[y[-1]/scale]
    for t in taus: initial.extend([(y[0]-y[-1])/scale/n,np.log(t)])
    low=[-np.inf]+sum(([-np.inf,np.log(tmin)] for _ in range(n)),[])
    high=[np.inf]+sum(([np.inf,np.log(tmax)] for _ in range(n)),[])
    f=least_squares(lambda p:(model(p,a,b,n)-y/scale)/(u/scale),initial,bounds=(low,high),max_nfev=10000)
    red=float(np.sum(f.fun**2)/(len(y)-len(initial)))
    tr=np.ones(len(initial)); tr[0]=scale; tr[1::2]=scale
    p=f.x*tr
    cov=np.linalg.pinv(f.jac.T@f.jac)*max(1,red)*tr[:,None]*tr[None,:]
    return p,cov,dict(success=bool(f.success),reduced_chi2=red,condition=float(np.linalg.cond(f.jac)))

def demo(path):
    rng=np.random.default_rng(7); rows=[]
    for direction,vs in [('forward',np.linspace(-.1,.1,11)),('reverse',np.linspace(.1,-.1,11))]:
        for k,(v0,v1) in enumerate(zip(vs[:-1],vs[1:])):
            a=np.arange(0,.15,.001); b=a+.001
            y=2e-12+(v1-v0)*(1e-9/.003*avg(a,b,.003)+.2e-9/.02*avg(a,b,.02))
            for j in range(len(a)):
                rows.append(['demo',direction,k,v0,v1,a[j],b[j],y[j]+rng.normal(0,1e-13),1e-13,2e-12,1e-14,1e-8,k>0])
    pd.DataFrame(rows,columns=Q).to_csv(path,index=False)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--qs',type=Path); p.add_argument('--hf',type=Path); p.add_argument('--demo',action='store_true')
    p.add_argument('--output',type=Path,default=Path('results'))
    p.add_argument('--model',choices=['none','exp1','exp2'],default='none')
    p.add_argument('--gaps',choices=['reject','bound','model'],default='reject')
    p.add_argument('--gap-bound-A',type=float)
    p.add_argument('--tail-n',type=int,default=12); p.add_argument('--tail-A',type=float,default=1e-12)
    p.add_argument('--tail-slope-A-s',type=float,default=1e-10)
    p.add_argument('--u-offset-A',type=float,default=0); p.add_argument('--u-leak-common-A',type=float,default=0)
    p.add_argument('--u-clock-rel',type=float,default=0); p.add_argument('--u-dv-V',type=float,default=0)
    p.add_argument('--r-bias-ohm',type=float,default=20000)
    p.add_argument('--derive-voltage',action='store_true'); p.add_argument('--time-bound-s',type=float,default=0)
    x=p.parse_args(); x.output.mkdir(parents=True,exist_ok=True)
    if x.tail_n<3 or x.tail_A<=0 or x.tail_slope_A_s<=0 or x.r_bias_ohm<=0: p.error('invalid positive parameter')
    if min(x.u_offset_A,x.u_leak_common_A,x.u_clock_rel,x.u_dv_V,x.time_bound_s)<0: p.error('negative uncertainty')
    if x.gaps=='model' and x.model=='none': p.error('model gap filling requires exp1/exp2')
    if x.gaps=='bound' and (x.gap_bound_A is None or x.gap_bound_A<=0): p.error('provide positive --gap-bound-A')
    if x.demo:
        x.qs=x.output/'demo_qs.csv'; demo(x.qs)
    if x.qs is None: p.error('provide --qs or --demo')
    d=read(x.qs,Q)
    if d.empty: raise ValueError('empty QS data')
    if not d.direction.isin(['forward','reverse']).all(): raise ValueError('invalid direction')
    if x.derive_voltage:
        cols=['vsource_before_V','vsource_after_V','ibias_before_A','ibias_after_A']
        if not set(cols)<=set(d): raise ValueError('Need '+str(cols))
        d['v_before_V']=d.vsource_before_V-x.r_bias_ohm*d.ibias_before_A
        d['v_after_V']=d.vsource_after_V-x.r_bias_ohm*d.ibias_after_A
    out=[]; fits=[]
    for key,g in d.groupby(K,sort=False):
        g=g.sort_values('a_s'); arr=g[Q[3:-1]].to_numpy(float)
        if not np.isfinite(arr).all(): raise ValueError(f'{key}: nonfinite data')
        if (g[['u_i_A','u_leak_ind_A','u_dt_s']]<0).any().any(): raise ValueError('negative uncertainty')
        if g.v_before_V.nunique()!=1 or g.v_after_V.nunique()!=1: raise ValueError('varying endpoints')
        a=g.a_s.to_numpy(); b=g.b_s.to_numpy(); w=b-a
        if len(g)<max(x.tail_n,8) or a[0]<0 or np.any(w<=0) or np.any(a[1:]<b[:-1]-1e-12): raise ValueError('invalid aperture sequence')
        dv=float(g.v_after_V.iloc[0]-g.v_before_V.iloc[0])
        if dv==0: raise ValueError('zero DUT voltage increment')
        y=(g.i_A-g.leak_A).to_numpy(); u=np.hypot(g.u_i_A,g.u_leak_ind_A).to_numpy()
        if np.any(u<=0): raise ValueError('positive independent uncertainty required')
        missing=[]; edge=0.
        for l,r in zip(a,b):
            if l-edge>1e-12: missing.append((edge,float(l)))
            edge=float(r)
        n=x.tail_n; t=(a[-n:]+b[-n:])/2; X=np.column_stack([np.ones(n),t-t.mean()]); weights=1/u[-n:]**2
        cov=np.linalg.inv(X.T@(weights[:,None]*X)); beta=cov@(X.T@(weights*y[-n:]))
        red=np.sum(((X@beta-y[-n:])/u[-n:])**2)/(n-2); cov*=max(1,float(red))
        ub=np.sqrt(cov[0,0]+x.u_offset_A**2+x.u_leak_common_A**2)
        settled=bool(abs(beta[0])+1.96*ub<=x.tail_A and abs(beta[1])+1.96*np.sqrt(cov[1,1])<=x.tail_slope_A_s)
        pre=bool(g.pre_settled.astype(str).str.lower().isin(['true','1']).all())
        qo=float(y@w); uqo=float(np.sqrt(np.sum((w*u)**2+(y*g.u_dt_s.to_numpy())**2)+
            w.sum()**2*(x.u_offset_A**2+x.u_leak_common_A**2)+(qo*x.u_clock_rel)**2))
        flags=[]
        if not pre: flags.append('INITIAL_STATE_UNCONFIRMED')
        if not settled: flags.append('TAIL_UNSETTLED')
        fitinfo={}; qgap=0.; bound=0.
        if x.model!='none':
            count=int(x.model[-1]); par,pcov,diag=fit(a,b,y,u,count)
            comp=sorted([(float(np.exp(par[2+2*j])),float(par[1+2*j]*np.exp(par[2+2*j]))) for j in range(count)])
            fitinfo=dict(**diag,parameters=par.tolist(),covariance=pcov.tolist(),tau_s_Q_C=comp,
                remaining_tail_C=sum(q*np.exp(-b[-1]/tau) for tau,q in comp))
            if not diag['success'] or diag['reduced_chi2']>5 or diag['condition']>1e8: flags.append('FIT_WARNING')
        if missing:
            if x.gaps=='reject': flags.append('MISSING_CHARGE')
            if x.gaps=='bound':
                bound=sum(r-l for l,r in missing)*x.gap_bound_A; flags.append('GAPS_BOUNDED')
            if x.gaps=='model':
                qgap=sum(area(par,l,r,count) for l,r in missing); flags.append('GAPS_MODEL_DEPENDENT')
        charge=qo+qgap; cap=charge/dv
        uc=float(np.hypot(uqo/dv,charge*x.u_dv_V/dv**2))
        usable=pre and settled and not missing
        out.append(dict(zip(K,key),v_mid_V=float((g.v_before_V.iloc[0]+g.v_after_V.iloc[0])/2),
            v_after_V=float(g.v_after_V.iloc[0]),q_observed_C=qo,u_q_observed_C=uqo,q_gap_model_C=qgap,
            q_gap_abs_bound_C=bound,c_sec_F=cap,u_c_observed_terms_F=uc,tail_A=float(beta[0]),
            tail_slope_A_s=float(beta[1]),pre_settled=pre,tail_settled=settled,usable_for_pair=usable,
            status=';'.join(flags) or 'NUMERICAL_CHECKS_PASSED'))
        fits.append(dict(key=[str(v) for v in key],missing_intervals_s=missing,fit=fitinfo))
    result=pd.DataFrame(out); result.to_csv(x.output/'qs_steps.csv',index=False)
    pairs=[]
    for run,g in result.groupby('run'):
        f=g[(g.direction=='forward')&g.usable_for_pair].sort_values('v_mid_V')
        r=g[(g.direction=='reverse')&g.usable_for_pair].sort_values('v_mid_V')
        if r.v_mid_V.duplicated().any(): raise ValueError('separate repeated cycles into runs')
        for _,v in f.iterrows():
            if len(r)>=2 and r.v_mid_V.min()<=v.v_mid_V<=r.v_mid_V.max():
                rev=float(np.interp(v.v_mid_V,r.v_mid_V,r.c_sec_F))
                pairs.append([run,v.v_mid_V,v.c_sec_F,rev,v.c_sec_F-rev])
    pd.DataFrame(pairs,columns=['run','v_mid_V','c_forward_F','c_reverse_F','difference_F']).to_csv(x.output/'forward_reverse.csv',index=False)
    if x.hf:
        h=read(x.hf,H)
        nums=h[H[3:]].to_numpy(float)
        if not np.isfinite(nums).all() or (h.frequency_Hz<=0).any() or (h.end_s<=h.start_s).any() or (h.vac_rms_V<0).any(): raise ValueError('invalid HF data')
        h['hf_window_valid']=(h.start_s-x.time_bound_s>=h.plateau_start_s)&(h.end_s+x.time_bound_s<=h.plateau_end_s)
        h['cp_F']=h.b_S/(2*np.pi*h.frequency_Hz)
        h['dp']=np.divide(h.g_S,h.b_S,out=np.full(len(h),np.nan),where=h.b_S.to_numpy()!=0)
        h['iac_rms_A']=np.hypot(h.g_S,h.b_S)*h.vac_rms_V
        joint=h.merge(result,on=K,how='left',validate='many_to_one',indicator=True)
        if (joint['_merge']!='both').any(): raise ValueError('HF key missing from QS')
        joint['delta_bias_V']=joint.vdc_V-joint.v_after_V
        joint.drop(columns='_merge').to_csv(x.output/'joint_records.csv',index=False)
    (x.output/'fits.json').write_text(json.dumps(fits,indent=2),encoding='utf-8')
    (x.output/'metadata.json').write_text(json.dumps(dict(arguments={k:str(v) if isinstance(v,Path) else v for k,v in vars(x).items()},
        warning='Offline processing. Partial uncertainty only. No trap attribution or AC divider from 20k resistor. Numerical checks are not a calibration certificate.'),indent=2),encoding='utf-8')
    print(x.output.resolve())
if __name__=='__main__': main()
